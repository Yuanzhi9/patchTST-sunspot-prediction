"""Run the preregistered PR132 standard PatchTST baseline search.

Phases are resumable:
    smoke   -> three single-fold one-epoch checks
    search  -> 96 TPE trials on development folds 1-4
    refine  -> extra seeds for the top trials
    audit   -> deferred-fold check for the selected candidate
    finalize -> compact result tables and plots
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PYTHON_PACKAGES = "/openbayes/home/python-packages"
OPTUNA_STORAGE = "sqlite:////openbayes/home/optuna/pr132_standard_v3_2026-11-20.db"
STUDY_NAME = "pr132-standard-v3-2026-11-20"
MANIFEST = ROOT / "configs/search_pr132_standard_2026-11-20.json"
OUT_ROOT = ROOT / "analysis_p132/search_standard"


def load_manifest() -> dict:
    return json.loads(MANIFEST.read_text(encoding="utf-8"))


def result_dir(des: str, fold: int, seed: int) -> Path | None:
    matches = [
        p
        for p in (ROOT / "results").iterdir()
        if p.is_dir() and f"_{des}_F{fold}_seed{seed}" in p.name
    ]
    return matches[0] if len(matches) == 1 else None


def result_complete(des: str, fold: int, seed: int) -> bool:
    path = result_dir(des, fold, seed)
    return bool(
        path
        and all(
            (path / name).exists()
            for name in [
                "pred.npy",
                "true.npy",
                "cv_window_meta.json",
                "p132_metrics.json",
                "p132_curve.csv",
            ]
        )
    )


def train_fold(
    des: str,
    params: dict,
    fold: int,
    seed: int,
    epochs: int = 50,
    force: bool = False,
) -> None:
    if not force and result_complete(des, fold, seed):
        return

    log_path = ROOT / "logs" / f"{des}-S{seed}-F{fold}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable,
        "-u",
        "run_base_cv5.py",
        "--cv_file",
        "configs/cv5_folds_p132_2026-10.json",
        "--cv_fold",
        str(fold),
        "--seq_len",
        str(params["seq_len"]),
        "--pred_len",
        "132",
        "--patch_len",
        str(params["patch_len"]),
        "--stride",
        str(params["stride"]),
        "--d_model",
        str(params["d_model"]),
        "--n_heads",
        str(params["n_heads"]),
        "--e_layers",
        str(params["e_layers"]),
        "--d_ff",
        str(params["d_ff"]),
        "--dropout",
        str(params["dropout"]),
        "--fc_dropout",
        str(params.get("fc_dropout", params["dropout"])),
        "--head_dropout",
        "0.0",
        "--train_epochs",
        str(epochs),
        "--patience",
        "100",
        "--batch_size",
        str(params["batch_size"]),
        "--learning_rate",
        str(params["learning_rate"]),
        "--random_seed",
        str(seed),
        "--des",
        des,
        "--use_gpu",
        "1",
    ]
    env = os.environ.copy()
    env["PYTHONPATH"] = f"{ROOT / 'PatchTST_supervised'}:{PYTHON_PACKAGES}"
    env["OMP_NUM_THREADS"] = "4"
    with log_path.open("w", encoding="utf-8") as log:
        proc = subprocess.run(
            cmd,
            cwd=ROOT,
            env=env,
            stdout=log,
            stderr=subprocess.STDOUT,
            text=True,
        )
    if proc.returncode != 0:
        raise RuntimeError(f"training failed: {des} F{fold} seed{seed}; see {log_path}")


def evaluate(des: str, seed: int, folds: list[int]) -> dict:
    out_dir = OUT_ROOT / f"{des}_seed{seed}"
    cmd = [
        sys.executable,
        "scripts/eval_p132_cv5.py",
        "--des",
        des,
        "--seed",
        str(seed),
        "--out_dir",
        str(out_dir),
    ]
    env = os.environ.copy()
    env["PYTHONPATH"] = f"{ROOT / 'PatchTST_supervised'}:{PYTHON_PACKAGES}"
    subprocess.run(cmd, cwd=ROOT, env=env, check=True)
    payload = json.loads((out_dir / "cv5_aggregate.json").read_text(encoding="utf-8"))
    actual_folds = sorted(int(row["fold"]) for row in payload["folds"])
    if actual_folds != sorted(folds):
        raise RuntimeError(f"{des} seed{seed}: folds {actual_folds}, expected {folds}")
    return payload


def amplitude_diagnostics(des: str, seed: int, folds: list[int]) -> dict:
    ratios = []
    negative = []
    for fold in folds:
        path = result_dir(des, fold, seed)
        if path is None:
            raise RuntimeError(f"missing result {des} F{fold} seed{seed}")
        curve = pd.read_csv(path / "p132_curve.csv")
        negative.append(float((curve["pred"] < 0).mean()))
        for _, group in curve.groupby("window_index"):
            true_amp = float(group["true"].max() - group["true"].min())
            if true_amp > 1:
                ratios.append(
                    float(group["pred"].max() - group["pred"].min()) / true_amp
                )
    return {
        "amplitude_ratio_mean": float(np.mean(ratios)) if ratios else None,
        "negative_fraction": float(np.mean(negative)),
    }


def aggregate_across_seeds(results: dict[int, dict]) -> dict:
    cycle = [float(v["cycle_MAE"]["mean"]) for v in results.values()]
    worst = [float(v["cycle_MAE"]["worst"]) for v in results.values()]
    full = [float(v["full_MAE"]["mean"]) for v in results.values()]
    return {
        "n_seeds": len(results),
        "cycle_MAE_seed_mean": float(np.mean(cycle)),
        "cycle_MAE_seed_std": float(np.std(cycle, ddof=1)) if len(cycle) > 1 else None,
        "cycle_MAE_across_seeds_worst": float(np.max(worst)),
        "full_MAE_seed_mean": float(np.mean(full)),
    }


def suggest_params(trial, cfg: dict) -> dict:
    seq_len = trial.suggest_categorical("seq_len", cfg["seq_len"])
    patch_len = trial.suggest_categorical("patch_len", cfg["patch_len"])
    shapes = []
    for d_model in cfg["d_model"]:
        for heads in cfg["n_heads"]:
            if d_model % heads:
                continue
            for d_ff in cfg["d_ff"]:
                if d_ff >= 2 * d_model:
                    shapes.append(f"D{d_model}-H{heads}-F{d_ff}")
    shape = trial.suggest_categorical("shape", shapes)
    d_model_text, heads_text, d_ff_text = shape.split("-")
    d_model = int(d_model_text[1:])
    heads = int(heads_text[1:])
    d_ff = int(d_ff_text[1:])
    return {
        "seq_len": seq_len,
        "patch_len": patch_len,
        "stride": patch_len // 2,
        "d_model": d_model,
        "n_heads": heads,
        "e_layers": trial.suggest_categorical("e_layers", cfg["e_layers"]),
        "d_ff": d_ff,
        "dropout": trial.suggest_categorical("dropout", cfg["dropout"]),
        "fc_dropout": trial.suggest_categorical("fc_dropout", cfg["fc_dropout"]),
        "learning_rate": trial.suggest_float(
            "learning_rate",
            float(cfg["learning_rate_min"]),
            float(cfg["learning_rate_max"]),
            log=True,
        ),
        "batch_size": trial.suggest_categorical("batch_size", cfg["batch_size"]),
    }


def run_candidate(
    des: str, params: dict, seed: int, folds: list[int], epochs: int = 50
) -> dict:
    for fold in folds:
        train_fold(des, params, fold, seed, epochs=epochs)
    payload = evaluate(des, seed, folds)
    payload["amplitude_diagnostics"] = amplitude_diagnostics(des, seed, folds)
    out_dir = OUT_ROOT / f"{des}_seed{seed}"
    (out_dir / "candidate_metrics.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    return payload


def phase_smoke(cfg: dict) -> None:
    errors = []
    for item in cfg["smoke"]:
        params = {k: item[k] for k in [
            "seq_len", "patch_len", "stride", "d_model", "n_heads",
            "e_layers", "d_ff", "dropout", "batch_size", "learning_rate"
        ]}
        des = item["id"]
        train_fold(des, params, 1, 2021, epochs=1, force=True)
        payload = evaluate(des, 2021, [1])
        path = result_dir(des, 1, 2021)
        pred = np.load(path / "pred.npy")
        true = np.load(path / "true.npy")
        if pred.shape != true.shape or pred.shape[1:] != (132, 1):
            errors.append(f"{des}: shape {pred.shape}/{true.shape}")
        if not np.isfinite(pred).all() or not np.isfinite(true).all():
            errors.append(f"{des}: non-finite values")
        if payload["cycle_MAE"]["mean"] is None:
            errors.append(f"{des}: missing cycle MAE")
        print(f"[smoke] {des}: ok", flush=True)
    if errors:
        raise RuntimeError("; ".join(errors))


def phase_search(cfg: dict) -> None:
    import optuna

    optuna.logging.set_verbosity(optuna.logging.WARNING)
    Path("/openbayes/home/optuna").mkdir(parents=True, exist_ok=True)
    study = optuna.create_study(
        study_name=STUDY_NAME,
        storage=OPTUNA_STORAGE,
        load_if_exists=True,
        direction="minimize",
    )
    # Anchor the search at the best known configuration from the preceding grid.
    # This does not hide exploration: it guarantees that the current PR132 standard
    # candidate is evaluated under the new search bookkeeping before TPE narrows.
    study.enqueue_trial(
        {
            "seq_len": 132,
            "patch_len": 36,
            "shape": "D128-H8-F2048",
            "e_layers": 2,
            "dropout": 0.3,
            "fc_dropout": 0.3,
            "learning_rate": 0.001,
            "batch_size": 32,
        },
        skip_if_exists=True,
    )
    target = int(cfg["trials"])
    completed = sum(t.state.name == "COMPLETE" for t in study.trials)
    remaining = max(0, target - completed)

    def objective(trial):
        params = suggest_params(trial, cfg)
        des = f"P132G3-T{trial.number:03d}"
        payload = run_candidate(des, params, 2021, cfg["development_folds"])
        amp = payload["amplitude_diagnostics"]
        trial.set_user_attr("des", des)
        trial.set_user_attr("model_params", params)
        trial.set_user_attr("cycle_MAE", float(payload["cycle_MAE"]["mean"]))
        trial.set_user_attr("cycle_worst", float(payload["cycle_MAE"]["worst"]))
        trial.set_user_attr("full_MAE", float(payload["full_MAE"]["mean"]))
        trial.set_user_attr("amplitude_ratio", amp["amplitude_ratio_mean"])
        trial.set_user_attr("negative_fraction", amp["negative_fraction"])
        print(
            f"[trial {trial.number:03d}] cycle={payload['cycle_MAE']['mean']:.4f} "
            f"worst={payload['cycle_MAE']['worst']:.4f} {params}",
            flush=True,
        )
        return float(payload["cycle_MAE"]["mean"])

    if remaining:
        study.optimize(objective, n_trials=remaining, gc_after_trial=True)
    rows = []
    for trial in study.trials:
        if trial.state.name != "COMPLETE":
            continue
        rows.append({"trial": trial.number, **trial.params, **trial.user_attrs, "objective": trial.value})
    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).sort_values("objective").to_csv(OUT_ROOT / "trials.csv", index=False)
    print(f"[search] completed {sum(t.state.name == 'COMPLETE' for t in study.trials)}/{target}", flush=True)


def study_trials():
    import optuna
    study = optuna.load_study(study_name=STUDY_NAME, storage=OPTUNA_STORAGE)
    return sorted(
        [t for t in study.trials if t.state.name == "COMPLETE"],
        key=lambda t: float(t.value),
    )


def phase_refine(cfg: dict) -> None:
    trials = study_trials()
    if not trials:
        raise RuntimeError("search has no completed trials")
    top10 = trials[: int(cfg["refine_top_n"])]
    summaries = []
    for trial in top10:
        des = trial.user_attrs["des"]
        params = dict(trial.user_attrs["model_params"])
        seed_results = {2021: json.loads((OUT_ROOT / f"{des}_seed2021/candidate_metrics.json").read_text())}
        for seed in cfg["refine_seeds"]:
            seed_results[seed] = run_candidate(des, params, seed, cfg["development_folds"])
        summary = aggregate_across_seeds(seed_results)
        summary.update({"trial": trial.number, "des": des, "params": params})
        summaries.append(summary)
        (OUT_ROOT / f"{des}_3seed_summary.json").write_text(
            json.dumps({"summary": summary, "seeds": seed_results}, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        print(f"[refine] {des} 3seed={summary['cycle_MAE_seed_mean']:.4f}", flush=True)
    frame = pd.DataFrame(summaries).sort_values("cycle_MAE_seed_mean")
    frame.to_json(OUT_ROOT / "top10_3seed.json", orient="records", indent=2)
    top3 = frame.head(int(cfg["final_top_n"])).to_dict("records")
    for item in top3:
        des = item["des"]
        # Take exact params from the matching Optuna trial.
        trial = next(t for t in trials if t.number == int(item["trial"]))
        params = dict(trial.user_attrs["model_params"])
        seed_results = {}
        for seed in [2021, *cfg["refine_seeds"], *cfg["final_seeds"]]:
            path = OUT_ROOT / f"{des}_seed{seed}/candidate_metrics.json"
            seed_results[seed] = json.loads(path.read_text()) if path.exists() else run_candidate(
                des, params, seed, cfg["development_folds"]
            )
        summary = aggregate_across_seeds(seed_results)
        summary.update({"trial": trial.number, "des": des, "params": params})
        item.clear()
        item.update(summary)
        (OUT_ROOT / f"{des}_5seed_summary.json").write_text(
            json.dumps({"summary": summary, "seeds": seed_results}, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
        print(f"[finalist] {des} 5seed={summary['cycle_MAE_seed_mean']:.4f}", flush=True)
    final_frame = pd.DataFrame(top3).sort_values("cycle_MAE_seed_mean")
    best_mean = float(final_frame.iloc[0]["cycle_MAE_seed_mean"])
    within = final_frame[final_frame["cycle_MAE_seed_mean"] <= best_mean * (1 + cfg["tie_tolerance"])]
    selected = within.sort_values(["cycle_MAE_across_seeds_worst", "cycle_MAE_seed_mean"]).iloc[0].to_dict()
    final_frame.to_json(OUT_ROOT / "top3_5seed.json", orient="records", indent=2)
    (OUT_ROOT / "selected_candidate.json").write_text(
        json.dumps(selected, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(f"[selected] {selected['des']} 5seed={selected['cycle_MAE_seed_mean']:.4f}", flush=True)


def phase_audit(cfg: dict) -> None:
    selected = json.loads((OUT_ROOT / "selected_candidate.json").read_text(encoding="utf-8"))
    des = selected["des"]
    params = dict(selected["params"])
    audits = {}
    for seed in cfg["audit_seeds"]:
        audits[seed] = run_candidate(des, params, seed, [5])
    payload = {
        "candidate": selected,
        "fold5": audits,
        "fold5_cycle_MAE_seed_mean": float(np.mean([v["cycle_MAE"]["mean"] for v in audits.values()])),
        "fold5_cycle_MAE_seed_std": float(np.std([v["cycle_MAE"]["mean"] for v in audits.values()], ddof=1)),
    }
    (OUT_ROOT / "fold5_audit.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(f"[audit] fold5={payload['fold5_cycle_MAE_seed_mean']:.4f}", flush=True)


def phase_finalize(cfg: dict) -> None:
    trials = pd.read_csv(OUT_ROOT / "trials.csv").sort_values("objective")
    selected = json.loads((OUT_ROOT / "selected_candidate.json").read_text(encoding="utf-8"))
    des = selected["des"]
    for seed in cfg["audit_seeds"]:
        evaluate(des, seed, [1, 2, 3, 4, 5])
    # Main seed: five folds; output plots.
    subprocess.run(
        [
            sys.executable,
            "scripts/plot_p132_cv5.py",
            "--des",
            des,
            "--seed",
            "2021",
        ],
        cwd=ROOT,
        check=True,
    )
    summary = {
        "selected": selected,
        "fold5_audit": json.loads((OUT_ROOT / "fold5_audit.json").read_text()),
        "top_trials": trials.head(10).to_dict("records"),
    }
    (OUT_ROOT / "final_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(f"[finalize] {des}", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=["smoke", "search", "refine", "audit", "finalize"])
    args = parser.parse_args()
    cfg = load_manifest()
    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    if args.phase == "smoke":
        phase_smoke(cfg)
    elif args.phase == "search":
        phase_search(cfg["search"])
    elif args.phase == "refine":
        phase_refine(
            {
                **cfg["search"],
                "tie_tolerance": cfg["selection"]["tie_tolerance"],
            }
        )
    elif args.phase == "audit":
        phase_audit(cfg["search"])
    elif args.phase == "finalize":
        phase_finalize(cfg["search"])


if __name__ == "__main__":
    main()
