# PR132 标准 PatchTST 超参数搜索（2026-11-20）

## 结论

本次 96 trial 搜索完成。最终选定 `P132G3-T086`：

```text
PR132-SL132-PL36-S18-D128-H2-E2-F2048-DO04-FC03-LR3E3-BS32
```

- 五 seed direct-cycle MAE：`40.2595 ± 0.5791`
- 五 seed 全滑窗 MAE：`41.9517`
- fold 5 延迟审计：`34.0610 ± 2.1189`
- 旧候选 direct-cycle MAE：`41.12 ± 1.25`

主指标改善约 2.1%，种子稳定性明显提高；但全滑窗 MAE 从旧候选约
`41.99` 到 `41.95`，基本不变。因此这不是全面精度突破，不能据此宣称
PatchTST 已解决 PR132 的长时距问题。

学习率约 `2.98e-3`，接近预登记搜索上界 `3e-3`。该候选只能称为
“当前预登记网格内最佳”，不能称为全局最优。

## 固定条件

| 项 | 值 |
|---|---|
| 数据 | SILSO 月均未平滑 SSN，1749-01 至 2026-10 |
| 输入 | `month_sin`, `month_cos`, `ssn` |
| 模型 | 标准 PatchTST，channel-independent |
| 输出 | direct132，一次预测 132 个月 |
| loss | MSE，无目标变换 |
| 标准化 | StandardScaler，仅用 inner-train 拟合 |
| fold | `configs/cv5_folds_p132_2026-10.json` |
| checkpoint | inner validation loss 最小 |

## 搜索与复核

1. 96 个 TPE trial，每个 trial 跑开发折 fold 1–4、seed 2021。
2. 前 10 名补 seed 2020/2022。
3. 前 3 名补 seed 2019/2023，形成五 seed 开发结果。
4. 选择规则以开发折 direct-cycle MAE 为主；3% 容差内比较跨 seed
   最差折，再比较均值。
5. 选定 T086 后，五 seed 跑 fold 5 延迟审计；fold 5 不参与选参。

前三名五 seed：

| trial | cycle MAE | seed std |
|---|---:|---:|
| T086 | 40.2595 | 0.5791 |
| T049 | 40.3085 | 1.4864 |
| T052 | 40.4943 | 0.9728 |

T086 seed 明细：

| seed | direct-cycle MAE | full MAE |
|---:|---:|---:|
| 2019 | 41.2583 | 42.1732 |
| 2020 | 39.9813 | 41.6154 |
| 2021 | 39.8698 | 42.1354 |
| 2022 | 39.9211 | 41.7926 |
| 2023 | 40.2669 | 42.0420 |

## 主要发现

- 稳定区域集中在 `SL132/PL36 + D128 + 2 层 encoder + dropout 0.4 +
  batch 32`。
- `SL264`、`SL336` 绝大多数明显变差。
- 最优学习率贴近上界，说明下一步若继续调参，应先做学习率外延，
  而不是继续在当前区间内随机抽取。
- direct-cycle 指标与全滑窗指标不一致。非重叠 132 月起点的选择会
  明显影响 direct-cycle 结果，因此必须两套口径同时报告。
- 连续更新真值的 update12/update24 诊断是真实业务收益；例如 seed 2021
  的同日期 MAE 从 one-shot `38.55` 降至 update12 `28.09`、
  update24 `32.08`。但这不是固定 lead 模型能力提升，且 PR24 同日期
  仍为 `26.85`。

## 证据文件

```text
analysis_p132/search_standard/trials.csv
analysis_p132/search_standard/top10_3seed.json
analysis_p132/search_standard/top3_5seed.json
analysis_p132/search_standard/selected_candidate.json
analysis_p132/search_standard/fold5_audit.json
analysis_p132/search_standard/final_summary.json
plots/P132G3-T086_p132_direct_cycles_seed2021.png
plots/P132G3-T086_p132_stability_seed2021.png
analysis_p132/update_cadence_standard/p132_update_cadence_seed2021.png
```

## 本轮修复

1. `tie_tolerance` 从错误的 `search` 配置层读取；改为从 `selection` 层读取。
2. 评估脚本增加 `--folds`，避免 fold5 审计误读 fold1–5。
3. `result_complete()` 改为只以训练产物判断是否重训，避免评估文件缺失时
   重跑完整 fold。

## 限制与后续

- CV5 是跨年代 blocked CV，不是完整未来顺序审计。
- 当前五个 fold 已在上一轮调参中出现过，fold5 只是延迟审计，
  不能当作完全干净的最终测试。
- PR132 的后续优化应先做学习率外延和更稳健的选模规则；更大规模的
  特征、物理轮廓和预训练实验优先在 PR24 主线上筛选，再回 PR132 确认。
