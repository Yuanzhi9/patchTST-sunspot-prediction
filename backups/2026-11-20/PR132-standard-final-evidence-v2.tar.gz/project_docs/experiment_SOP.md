# 实验操作规程

> 为什么有这份规程：12 个坑的教训，每条对应下面一条规则。
> 这份文件给两个读者看——你 和 未来跟你协作的 AI。
> 2026-08-14 追加阶段1期间新踩的 10 个坑（见文末"阶段1新增坑"）。

---

## 阶段1新增坑（2026-08-12 ~ 08-14 复盘，10 条）

> 每条 = 现象 → 根因 → 已固化的对策。踩过一次的坑不许踩第二次。

| # | 坑 | 根因 | 对策（已固化） |
|---|-----|------|---------------|
| 13 | 并行训练 OOM，SSH 断连，实验全军覆没 | 两个 sl336 进程吃满 4 核+内存（8GB 无 swap） | 串行铁律 + PID 锁 + 内存预检（launch 脚本） |
| 14 | 训练"卡死"无任何输出 | python stdout 缓冲 | 训练命令必带 `-u` |
| 15 | SSH 断连杀掉训练进程 | 未加 nohup | nohup+setsid（launch 脚本） |
| 16 | 两代实验口径混比，结论反转两次 | train→test 用最终模型（`exp_main.py:287` 加载最佳权重的代码 04.02 被注释；补测路径 `exp_main.py:296-306` 才加载 `full_checkpoint.pth`），与 `--is_training 0` 补测口径不同 | 正式实验统一命令链（train && 补测）最佳模型口径，见 §4 |
| 17 | 可复现性门禁误报 11.1% 偏差 | 门禁拿两种口径数据互比 | 门禁比较必须同口径 |
| 18 | 证据链断裂：补测后 npy 未 commit，远程 checkout 后数字对不上 | commit 只 add 了备份文件，漏了被覆盖的 npy | 五件证据链 + commit 前 `git status` 逐项核对 |
| 19 | Round 1 跑完没写记录就开 Round 2 | 纪律松懈 | 每实验完成即落盘，不攒账 |
| 20 | 结论表述简化过度（"patch_len 不敏感"，实际 12→16 敏感 6.9%） | 总结时只给方向不给区间 | 敏感/不敏感结论必须精确到区间+百分比+单种子标注 |
| 21 | 建议换任务逃避困难、说"任何模型都推不出" | 研究心态问题 | 迎难而上；区分"误差有客观下限"（研究定位）与"不能预测"（泄气话） |
| 22 | 命令链/后台化的引号与 `&` 坑（两次翻车） | bash 语法组织不当 | 命令链先迷你测试再实战；后台化命令单独组织 |
| 23 | 变换管线只改逆变换、漏正变换调用点（pow07 首评荒谬值 213.57） | 三处改动不同步 | 变换三处（正变换/逆变换/回填）一次改齐；改后先跑"往返恒等+锚点回归"双验证，再跑新变换实验 |
| 24 | block 脚本 z_block 未按 block_size 截断（自检 FAIL 抓到） | 新脚本无正确性验证 | 新评估脚本必须设计"退化自检"（block=1 必须逐位等于滚动结果），FAIL 不出图不入实验 |
| 25 | 多模型对比图漏传 target_transform（pow23 图 MAE 与记值不符） | 变换模型调用路径遗漏 | 变换模型的所有评估/画图调用必须带同一 target_transform；"图内 MAE=已记值"为出图门禁 |
| 26 | 口径分裂：全步与滚动/block 结论可相反（wmse_th 全步恶化7%但滚动改善33%） | 混合提前期的口径与使用场景不匹配 | 按使用场景选口径（滚动场景看step0/滚动MAE，block场景看block轨迹MAE）；阶段3外推以滚动/block为主；全步保留为"远期输出退化体检" |
| 27 | 主控文档只在尾部追加新章节，顶部"当前状态"快照不更新（roadmap/AGENTS 落后两个阶段） | 无状态快照同步纪律 | 主控文档顶部的状态快照必须随进度同步更新，禁止只在尾部追加。命令是铁是钢 |
| 28 | 实验跑前没回顾历史错误，同类错误反复（代码漏commit 两次） | 无跑前回顾门禁 | SOP §1 预检表加必填行："坑清单回顾：本实验可能踩的坑编号是 ___"；不填不 launch；犯错当天补入坑清单 |

### 换机后新增坑（2026-10-10，新云服务器 torch 2.8 + numpy 2.2，6 条）

> 与"阶段1新增坑"同一体例：现象 → 根因 → 对策。全部在 EXP-25/26 换机时实际踩到。

| # | 坑 | 根因 | 对策（已固化） |
|---|-----|------|---------------|
| 29 | 补测加载 checkpoint 报 `UnpicklingError`，训练白跑 | torch≥2.6 把 `torch.load` 的 `weights_only` 默认值从 `False` 改成 `True`，而 `full_checkpoint.pth` 含 `argparse.Namespace`/numpy 标量与 dtype | `exp_main._load_checkpoint()` 显式 `weights_only=False`（**仅限本项目自身产物**，勿用于外部 checkpoint）。白名单 `add_safe_globals` 不可行——需放行的类型随 numpy 版本漂移 |
| 30 | 训练启动即崩：`AttributeError: np.Inf was removed in the NumPy 2.0 release` | numpy 2.0 移除 `np.Inf` 别名 | 改 `np.inf`（3 处 `utils/tools.py`，含 `sunspot_code_package` 与 FEDformer 副本） |
| 31 | `eval_metrics.py` / `roll_eval.py` 的 `--config` 模式**必然** IndexError | results 目录名格式串的占位符比实参多一个（漏了 `--itr` 的 `_0` 后缀）。**属既有 bug，不是新环境引入**——说明这两个脚本的 config 模式历史上可能从未跑通 | 补传 `itr-1`；改评估脚本后按 §5 跑 `scripts/test_eval.py` 回归（EXP-14 锚点 9.08/23.87/0.568 逐位重现） |
| 32 | 同一 checkpoint 的滚动 MAE 出现 30.32 与记录 50.41 相差 40%，被误判为"滚动口径不稳"，进而动摇 block 优于滚动 44-59% 这条阶段3 唯一策略依据 | `roll_eval.py` 旧默认 `n_roll=70`，而 `plot_rolling.py` / `b23_block_eval.py` 用**整段测试期**（W1=148 / W2=132 / W3=71）。用默认值跑得到的不是记录基线 | `n_roll` 默认改为由 `--test_end`（或 config 的 `test_end`）推出整段；两者都没有则**报错退出**，不静默兜底（刻意不用文件长度兜底：CSV 到 2025-10，W1 会错算成 351 月）。**铁律：任何滚动数字必须同时记录段长** |
| 33 | 配置冻结时 `num_train` 静默取默认 3119，而 W1 应为 2838 → 首轮算出的物理四指标**全部作废**（看起来还合理：全步 23.53 vs 正确的 23.37） | `save_config.py` 的 `--num_train` 默认值 3119，不随日期切分自动推导 | 显式传 `--num_train`；**跑通 ≠ 跑对**——物理值必须用 `data_pipeline.md` 三窗口表（W1 2838 / W2 2986 / W3 3118）逐项核对 |
| 34 | 把"过期的标准 ARGS"当权威基线，跑完才发现跑的是旧配置 | §4 的标准 ARGS 停在 Round 5 dropout 扫描**之前**（`dropout 0.05`），而阶段1 最终基线是 `EXP-18-5b`（`dropout 0.2 / fc_dropout 0.2`） | ①§4 的 ARGS 已在下文改为 dropout 0.2；②**凡"基线"必须标注=哪个实验 ID**，不写 ID 的基线描述一律视为不可信 |

### 证据链坑（2026-10-11 景修审计 EXP-27~30 提交结果，2 条）

> 上次踩的坑同一性质：**结论齐了、过程漏了**。审计由景修发起，不是自己发现的——这条本身也是教训。

| # | 坑 | 根因 | 对策（已固化） |
|---|-----|------|---------------|
| 35 | **commit 漏掉未跟踪的原始训练日志**：EXP-27~30 的 `logs/EXP-*.log`（各 318 行，含逐 epoch train/val loss、学习率、EarlyStopping counter）未入库，远端只剩结论、没有过程，别人 clone 后复现不了训练动态 | commit 时只 `git add` 了自己这次改过的文件，**没有按"未跟踪文件全量"对账**。反例就在眼前：同批的 EXP-25/26 日志已入库，标准摆着却没比对 | §6 记录节新增门禁「提交前核对未跟踪文件」：`git status --porcelain --untracked-files=all`，逐条把未跟踪文件判为「证据→提交」或「残留→ignore」，**有未归类的就不许 commit** |
| 36 | 运行残留混进版本库：`logs/EXP-25.pid` 被提交，而同类的 `EXP-26.pid`/`EXP-30.pid` 没有——同一类文件两种处理 | `.gitignore` 无 pid 规则，pid 进不进库取决于当时顺手不顺手 | `.gitignore` 加 `*.pid`（消融分支/GPU-exp26/主线三处同步）；已入库的 `EXP-25.pid` 属删文件，**待景修批准后** `git rm --cached` |

---

## 两档

| 档位 | 用在哪 | 记录方式 |
|------|--------|---------|
| 全流程 | 正式对照实验（一次一个变量） | 模板 + 索引表 |
| 批量 | 参数扫描（如 seq_len sweep） | 汇总表，不逐次填模板 |

---

## 全流程

### 1. 实验前（5 分钟，不写完不跑）

[ ] **训练入口脚本**：
    → 传统固定窗口实验：`run_longExp.py`（原管线）
    → 2026-11 顺序块五折实验：`run_base_cv5.py`（独立 CV5 管线，必须显式传 `--cv_fold`）
    → `run_sunspot_fixed.py` 仅为 EXP-13/14/15 快速校准，不做新实验
    → 运行时：`PYTHONPATH=PatchTST_supervised python3 run_longExp.py ...`
    → run_longExp.py 的 checkpoint 存 `./checkpoints/`（不是 `PatchTST_supervised/checkpoints/`）

> ⚠️ **跑前门禁（2026-08-19 起，铁律）**：
> - 预检表必须跑前完成——**事后补写不算数，只作留档**。本清单不填完不 launch
> - **坑清单回顾（必填行）**：本实验可能踩的坑编号是 ___（对照本 SOP 坑 1-28 过一遍）；不填不 launch
> - 犯错当天补入坑清单，不让同一个坑发生第二次

[ ] **features 确认**：MS（单目标预测SSN）还是 M（多变量全通道预测）？
    → 对照基线用什么就跟着用什么。当前约定：MS

[ ] **batch_size / num_workers / enc_in**：与对照基线一致
    → Baseline B 为 bs=32, num_workers=0, enc_in=3

[ ] **数据路径**：`--root_path` 显式传 `./PatchTST_supervised/dataset/`（run_longExp.py 默认是 `./data/ETT/` 会错）

[ ] **可证伪假设**（三行填完）：
    如果有效，step0 ≤ ___ 且 E_r ≤ ___
    如果无效，step0 ≈ ___
    如果结果是 ___ → 推论是 ___

[ ] **预尸检**：如果两周后证明这实验是废物，最可能因为什么？
    → 回答后检查：前提条件对吗（mode/数据范围/归一化）？

[ ] **文献先例**：这个方向是否已有文献做过？
    → 查 `literature/literature_reading_notes.md` 总览表（Ctrl+F 关键词）
    → 有 → 读对应详注（`literature_reading_notes_detailed.md`），记录"别人做到什么精度、踩了什么坑"
    → 无 → 标注"无文献先例"，写入实验文档作为背景

[ ] 只改了一个变量？是 ___（≥2 → 不跑）

[ ] 对照基线：___（索引表里的实验 ID）

[ ] **参数对照表**（逐项核对完才跑）：
    对照基线的每项参数，本次实验值必须与之一致（除改动变量外）。

| 参数 | 对照基线值 | 本次实验值 | 一致？ |
|------|----------|----------|--------|
| 训练入口 | run_longExp.py | | [ ] |
| features | __ | | [ ] |
| seq_len | __ | | [ ] |
| batch_size | __ | | | [ ] |
| num_workers | __ | | [ ] |
| enc_in | __ | | [ ] |
| 其余... | __ | | [ ] |

> ⚠️ **训练脚本的说明：**
> `run_longExp.py`：传统固定窗口实验入口。
> `run_base_cv5.py`：`BASE-2026-11-M` 顺序块五折专用入口；外层验证只打分一次，
> 旧 `Dataset_Custom` / `Exp_Main` 不被它调用。两者不能混跑同一条结果链。
> `run_sunspot_fixed.py`：仅 EXP-13/14/15 的快速校准工具。用它跑新实验 = EXP-16/16b 教训（两次作废）。不要踩同一个坑。

[ ] 这个结论只能用在什么前提条件下？
    （mode: M/MS？数据: 1749+/1867+？epochs: 10/50？）

[ ] 成功标准：MAE 从 ___ 到 ___ 算有效；不到 ___ 算无效

### 2. 工作区隔离

[ ] `git worktree add ../EXP-XX -b EXP-XX`
[ ] `cd ../EXP-XX`
[ ] 读主项目 `AGENTS.md` 和 `experiment_SOP.md`

### 3. 配置冻结

```bash
python ../save_config.py EXP-XX --reason "一句话目的"
```
→ 输出 `configs/EXP-XX_YYYY-MM-DD.json`

### 4. 训练

BASE-2026-11-M 顺序块五折训练示例（必须逐折串行）：

```bash
PYTHONPATH="./PatchTST_supervised" python3 -u run_base_cv5.py \
  --cv_fold 1 --seq_len 132 --pred_len 24 --patch_len 36 --stride 18 \
  --d_model 128 --n_heads 8 --e_layers 2 --d_ff 2048 \
  --dropout 0.2 --fc_dropout 0.2 --train_epochs 50 --patience 100 \
  --batch_size 32 --learning_rate 0.0003 --random_seed 2021 \
  --des B26M-XXXX --use_gpu 1
```

如需等训练窗口数对照，额外传 `--train_window_limit N`；原始窗口数和采样方式会写入
`cv_window_meta.json` 的 `train_window_sampling`。不要把该参数用于普通调参实验。

> ⚠️ **2026-08-14 口径规则（必须遵守）**：正式实验统一使用**命令链模式**（train && 补测），
> 正式评估对象 = **最佳 val 模型**（EarlyStopping 保存的 full_checkpoint.pth）。
> 原因：2026-08-13 发现 50ep 下 sl336 严重过拟合（val loss epoch4 后连续 46 轮恶化），
> train→test 同进程时 test 用内存中的最终模型（`exp_main.py:287` 加载最佳权重的代码 04.02 被注释；补测路径 `exp_main.py:296-306` 才加载 `full_checkpoint.pth`），
> 导致最终模型口径下结论反转。补测口径与标准 ML early stopping 实践一致。

```bash
# ⚠️ 2026-10-10 更新：ARGS 中的 dropout/fc_dropout 已由 0.05 改为 **0.2**，
#    与原基线一致。当前基线见 project_docs/STATE.md（阶段1 定论 = EXP-18-5b，Round 5 dropout 扫描胜者：
#    W1 全步 22.62 / step0 11.01 / R² 0.789 / E_r -24.4 / 滚动 50.41(148月)）。
#    旧版此处写 0.05 是 Round 5 之前的 0b 配置，已作废——见坑清单 34。
# 标准启动（命令链模式，经 launch 脚本）：
./scripts/launch_experiment.sh EXP-XX bash -c 'ARGS="--model_id sunspot --model PatchTST --data custom --root_path ./PatchTST_supervised/dataset/ --data_path sunspot_with_cycle.csv --features MS --target ssn --enc_in 3 --test_start 1996-08 --test_end 2008-11 --seq_len 336 --label_len 48 --pred_len 24 --d_model 128 --n_heads 8 --e_layers 2 --d_ff 2048 --patch_len 16 --stride 8 --revin 1 --affine 0 --dropout 0.2 --fc_dropout 0.2 --head_dropout 0.0 --individual 0 --train_epochs 50 --patience 100 --batch_size 16 --learning_rate 0.0001 --loss mse --activation gelu --random_seed 2021 --num_workers 0 --itr 1 --des EXP-XX"; python3 -u run_longExp.py --is_training 1 $ARGS && python3 -u run_longExp.py --is_training 0 $ARGS'
```

要点：
- `ARGS` 变量写一次参数、两次复用，杜绝 train/补测 参数抄错（抄错=找不到 checkpoint）
- `&&`：训练中途崩溃 → 补测不执行 → npy 不存在 → 验收直接发现失败（无假证据）
- 训练段自动 test 产生的 npy/result.txt 行为"最终模型口径"参考值；**正式引用补测段结果**
- 每个实验 result.txt 会有两行 z-score（训练段+补测段），记录文件里标注哪行是正式值
- 补测前若需要保留最终模型口径 npy（历史实验收口时），备份命名：`pred.bak_<日期>_final-model.npy`

```bash
# 旧格式（仅最终模型口径，不推荐用于正式实验）：
PYTHONPATH=PatchTST_supervised python3 run_longExp.py \
  --is_training 1 --model_id sunspot --model PatchTST --data custom \
  --root_path ./PatchTST_supervised/dataset/ \
  --features MS --target ssn --enc_in 3 \
  --seq_len 96 --label_len 48 --pred_len 24 \
  --d_model 128 --n_heads 8 --e_layers 2 --d_ff 2048 \
  --patch_len 16 --stride 8 --revin 1 --dropout 0.05 \
  --train_epochs 10 --patience 20 --batch_size 32 --learning_rate 0.0001 --loss mse \
  --itr 1 --num_workers 0 --activation gelu --des EXP-XX
  # 所有参数显式 CLI 传入，不修改 run_longExp.py 源码
  # ⚠️ 上例是 EXP-14 默认配置，实验时替换为实际参数
```
⚠️ 所有参数通过 CLI 传入 run_longExp.py，不修改源码。以下是代码改变的决策树：

### 4-B. 如果 CLI 参数不够——代码改变处置规则

> **4-B 附：改数据的场景**（加物理参数特征 / 换目标变换如 sqrt / 加新 CSV 列），
> 走 `project_docs/data_pipeline.md` 的"加特征/换目标改动检查清单"（9 项逐项勾选）。
> §4-B 管"改代码"，检查清单管"改数据"，两者不同但常同时触发——改动后都必须做回归验证（对拍锚点 + test_eval.py）。

```
实验需要改代码？
  ├─ 只是改参数 → CLI 传参（已覆盖，OK）
  │
  ├─ 改 1-5 行模型代码（如 PatchTST.py 加 ReLU head）
  │     → 在 run_longExp.py 加一个 CLI 开关参数（如 --head_activation relu）
  │     → 模型初始化时读此参数，决定是否执行该分支
  │     → 不复制文件，不改源码结构。一个 commit 包含：CLI 参数 + 模型内条件分支
  │     → 对照基线用同一个脚本，不破坏可比性
  │
  └─ 改大量代码（如新增 GRC 残差校正模块、换模型架构）
        → 🛑 STOP。停下来跟我（用户）讨论：
          a. 需要新建哪些文件，放哪个目录
          b. 如何跟现有 eval/roll_eval 管线对接
          c. 验证标准是什么
          d. 是否保留旧版本脚本做对照
        → 我拍板后再动工。
```

### 4-C. 需要讨论的待议项（2026-08-10 标记，等用户回复）

| # | 问题 | 为什么必须讨论 |
|---|------|--------------|
| 1 | A1（ReLU head）预期效果怎么定？ | Stage 0 在 MinMax 下做过 ReLU，但 MS+StandardScaler 下没试过——成功标准是"负值率下降"还是"step0 改善"？ |
| 2 | GRC 重度代码改动的具体方案 | 需要用户描述完整 pipeline（残差收集→梯度计算→AdaBoost→叠加），才知道要建什么文件 |
| 3 | GRC 在多步预测下取哪个残差 | 模型输出是 (47, 24) 矩阵——GRC 用 step0 残差还是全 24 步？ |
| 4 | 实验前没有跟导师对齐过定位 | 当前阶段标注"待与导师对齐"——GRC/A1 等方向是否要先搁置等导师反馈？ |

### 5. 评估（门禁——缺一个不算完成）

BASE-2026-11-M 的五折实验使用：

```bash
python3 scripts/eval_cv5.py --des B26M-XXXX --seed 2021
python3 scripts/plot_cv5.py --des B26M-XXXX --seed 2021
```

出图后必须检查 PNG/PDF 都存在，并确认图内 block24 MAE 与 `analysis/<des>_seed<N>/cv5_summary.csv` 一致。

传统固定窗口实验继续使用下面的 `eval_metrics.py` 流程。

```bash
python ../scripts/eval_metrics.py --config configs/EXP-XX_YYYY-MM-DD.json
```

固定输出：
- [ ] step0 MAE（物理）：______
- [ ] 全步 MAE（物理）：______
- [ ] E_r（峰值幅度误差）：______
- [ ] E_m（峰值时间误差）：______
- [ ] 误差分层：0-50 / 50-100 / 100-150 / >150
- [ ] 滚动 MAE（每一步推进1月，滚动70月）：
    ⚠️ 已自动化：`python ../roll_eval.py --config configs/EXP-XX.json`。
    正式对照实验需根据实验目的决定是否跑：
    - 基线实验（如 Baseline B 复现）→ 必须跑
     - 参数消融（如改 loss/激活）→ 可不跑（全步已覆盖）
    结果解读：前期 MAE 和后期 MAE 的比值反映误差累积速度。

[ ] **改过评估脚本？** → `python scripts/test_eval.py` 确认回归正常
    （用 EXP-14 已知结果验证 eval_metrics.py 没被改坏）

### 6. 记录（先结论，后细节）

> **文档更新三分类（2026-08-19 起，铁律）**——项目文档分三类，各按触发时机更新：

| 类别 | 文件 | 更新时机 |
|------|------|---------|
| 实时更新 | result.txt、experiment_history 索引表、实验记录文件（跑前预检表+跑后结果）、SOP 未做方向追踪表 | 每个实验完成即更新（五件证据链的一部分） |
| 阶段更新 | project_roadmap.md（§一状态表+待办看板）、AGENTS.md（结论摘要+当前阶段）、experiment_history 的 Stage 详情节、阶段总结文档、experiment_SOP.md、data_pipeline.md | 每阶段/每系列完成时刷新；规则/管线变更时即时改 |
| 交接文档 | ONBOARDING.md（给下一位合作 AI） | 每次重大变化后更新（阶段完成/方向变化/合作心得积累时），必须反映最新情况 |
| 日志性质 | diary/YYYY-MM-DD.md、实验记录文件的"收获/不足"节 | 每天结束写当天；犯错当天记录事故复盘 |

三条铁律：①实时更新不欠账（实验当天闭环）；②阶段更新不拖延（系列收口时一次性刷新顶部快照——2026-08-15 欠账的教训）；③日志当天写，隔天补写必须标注"补写"。

[ ] 一句话结论（跑完立刻写，别拖）：
    "___：step0 ___→___，全步 ___→___，有效/无效"

[ ] **实验收尾判定**（写结论时同时标注，写进索引表）：
    ✅ 通过：假设成立，结论可进入知识库
    ⚠️ 存疑：数据不足以判定，需要对照实验
    ❌ 无效：方法论错误（如用错脚本），结论不采用

[ ] 填 `project_docs/experiment_template.md`

[ ] 追加索引表一行（`project_docs/experiment_history.md` 顶部）

[ ] 追加 `result.txt` 一行

[ ] 更新未做方向追踪表（§8）

[ ] **提交前核对未跟踪文件（2026-10-11 起，铁律，坑 35）**：
    `git status --porcelain --untracked-files=all` → 逐条判断每个未跟踪文件，只许两个归类：
    - **证据 → 必须提交**：`logs/EXP-*.log`（原始训练日志，逐 epoch 过程）、`results/*/pred.npy|true.npy`、
      `configs/*.json`、`plots/*.png`、`test_results/*/0.pdf`
    - **残留 → ignore**：`*.pid`、`__pycache__/`、`*.pth`、`.ipynb_checkpoints/`
    → **有未归类的文件就不许 commit**。"记录写完了"不等于"证据齐了"。

[ ] git add → commit → push

### 7. 红线

### 6-B. 选模纪律 —— 三条硬规矩（2026-10-11 景修批准，纪律条款）

> 背景：`EXP-ROUND0` 体检证明现行"最佳 val 模型"口径不稳（W3 上 best-val 轮与 best-test 轮差 38 轮，
> 且 W3 上 best-val 比末轮差 20%）。讨论稿：`project_docs/discuss_2026-10-11_选模规则.md`。

1. **绝对不能用测试集挑模型。** 选模型 / 选超参 / 选 epoch 只能用验证集（或完全不用 val 的确定性规则）。
   用测试集挑，测试分数就失去意义（乐观偏差）——**这是纪律，不是建议**。任何"看 test 哪一轮好就用哪一轮"一律作废。
2. **验证集必须与测试段"同机制"。** 两者跨分布（如跨太阳活动周、振幅档位不同）时，按验证集挑会系统性挑错；
   这种情况下必须改用不依赖 val 的规则（固定轮次 / 权重平均），并在记录里写明"为何不用 val 挑"。
3. **选模 / 早停规则属于方法，必须写进记录与 STATE。** 报告必须写明用的是哪条规则（best-val / 平滑 val /
   固定轮次 N / 末轮 / 权重平均），以及为什么。参考文献：Prechelt (1998/2012) *Early Stopping — But When?*。

**违反其中任何一条的实验，结论不得进入项目知识库。**

- 改 ≥2 个变量 → 不跑
- z-score RSE 和物理 MAE 混用 → 不算
- "看看结果再说" → 没写假设就不跑
- 四个指标缺一 → 不算完成
- 跑完说不出"它告诉了我什么" → 必须说出来再开下一个
- 说不出来"什么样算无效" → 假设不完整，不跑
- 直接修改 run_longExp.py 源码来适配实验 → 不跑（用 CLI 传参，或复制文件标注差异）
- 对照基线参数没逐项核对过 → 不跑（先填参数对照表）
- 不确定归一化方法和逆操作是否匹配 → 不跑（先跑验证命令对拍已知结果）

### 8. 失败处理

连续 3 个实验没超过 10% 改善 → 停止，写总结

实验前提是错的（如 mode 不对、归一化不匹配） → 不补实验，先纠正前提再开新方向

自己也不知道"它说明了什么" → 不跑下一个实验

---

## 批量

适用场景：参数扫描（如 seq_len=48/96/132/192）

[ ] 扫描矩阵：变量名 × 取值列表
[ ] 存 `scan_config.json`（矩阵 + 固定参数）
[ ] 预期趋势：参数往哪个方向，指标应该往哪个方向
[ ] 跑
[ ] 每行四个固定指标 + 一句话结论
[ ] 汇总成一张表，追加到 `project_docs/experiment_history.md` 末尾
[ ] 每个子实验的 config JSON 存 `configs/scan_ID_N.json`
[ ] commit 时：scan_config.json + 汇总表 + 所有 config JSON

---

## 未做方向追踪

跑完一个实验后扫一眼此表。能顺手做就做，不能就更新"为什么没做"。

| 方向 | 提出日期 | 来源 | 为什么没做 | 还做吗 |
|------|---------|------|-----------|--------|
| ReLU head (A1) | 05.07 | A-H 清单 | Round 6 已测 FFN 内部 relu（差 1.5% 无差异）；输出层 ReLU 未测 | ⬜ 低优先级 |
| 高值加权 loss (D1) | 05.07 | A-H 清单 | 排队中 | ✅ 阶段1遗留任务 |
| Log/sqrt 变换 (E1) | 05.07 | A-H 清单 | 排队中（峰值压制机制 2 的对策） | ✅ 阶段1遗留任务 |
| 低估非对称惩罚 | 08.14 | 峰值机制分析 | 新提出 | ✅ 阶段1遗留任务 |
| RevIN 诊断（关掉/替代） | 08.14 | 峰值机制分析（机制3） | 新提出 | ✅ 阶段1遗留任务 |
| 物理先验特征注入 | 08.14 | 样本天花板对策 | 方案待设计（M4包络/相位/Hilbert时钟） | ✅ 之后讨论 |
| pred_len 验证 (12/24/48) | 08.14 | 知识缺口 | 沿用历史 24 未验证 | ✅ 阶段1遗留任务 |
| 相位编码 | — | — | — | ⬜ |
| GRC 残差校正 | — | 文献 | — | ⬜ |
| d_model 子轮 (64/256) | 08.12 | 阶段1方案 | ✅ Round 4 已做：均劣于 128，维持 | ✅ 完成 |
| dropout 扫描 | 08.12 | 阶段1方案 | ✅ Round 5 已做：0.2 胜（+5.2%） | ✅ 完成 |
| activation relu | 08.12 | 阶段1方案 | ✅ Round 6 已做：无差异，维持 gelu | ✅ 完成 |
| individual=1 | 08.12 | 阶段1方案 | ✅ Round 7 已做：恶化 6.7%，维持 0 | ✅ 完成 |
| e_layers 扫描 | 08.12 | 阶段1方案 | ✅ Round 2 已做：无差异，维持 2 | ✅ 完成 |
| d_ff 扫描 | 08.12 | 阶段1方案 | ✅ Round 3 已做：单调，维持 2048 | ✅ 完成 |
| patch_len/stride 扫描 | 08.12 | 阶段1方案 | ✅ Round 1 已做：16 维持 | ✅ 完成 |
| seq_len 对照 | 08.12 | 阶段1方案 | ✅ Round 0 已做：336 胜 | ✅ 完成 |
| 多 seed 验证 | 08.12 | 阶段1方案 | 历史阶段单种子限制；B26M P36/P24 已补 2019/2020，lr 有 P36 三 seed | 🟡 B26M seed2022/2023 未做 |
| 误差分解（偏差/方差） | 08.14 | 阶段1价值 D 项 | 用现成 npy 可做 | ✅ 阶段1遗留任务 |
| 与 M4 同口径对拍 | 08.14 | 阶段1价值 D 项 | — | ✅ 阶段1遗留任务 |
| 滚动误差逐月演化 | 08.14 | 阶段1价值 D 项 | — | ✅ 阶段1遗留任务 |
| E_m 系统分析 | 08.14 | 阶段1价值 D 项 | — | ✅ 阶段1遗留任务 |
| 最佳模型口径统一 | 08.13 | 门禁触发发现 | ✅ 已定：方案 B 命令链（train && 补测），固化于 §4 | ✅ 已定 |
| EXP-20-1 RevIN=0 诊断 | 08.14 | 峰值机制3对策 | ✅ 已完成：滚动崩溃，机制3证伪（RevIN=稳定性支柱） | ✅ 完成 |
| EXP-20-2 pred_len 12/48 验证 | 08.14 | 知识缺口 | ✅ 已完成：pl48 滚动禁区，维持 24 | ✅ 完成 |
| EXP-20-3 高值加权 MSE | 08.14 | 峰值机制1对策 | ✅ 已完成：α=1.0 峰值改善92%但全步恶化14.6% | ✅ 完成 |
| EXP-20-4 sqrt 变换 | 08.14 | 峰值机制2对策 | ✅ 已完成：滚动改善45%但峰值更差 | ✅ 完成 |
| EXP-21 变换系列 (pow07/pow23/log1p) | 08.15 | 机制2/4 | ✅ 已完成：pow23 滚动22.13最优；log1p 全步E_r=+1.3 | ✅ 完成 |
| EXP-22 loss系列 (mae/wmseα0.5/wmse_th/asym) | 08.15 | 机制1 | ✅ 已完成：wmse_th 最佳（峰-6.2/滚动33.92） | ✅ 完成 |
| EXP-23 block 外推策略 | 08.15 | 阶段3前置 | ✅ 已完成：block24无重叠三窗口优于滚动44-59% | ✅ 完成 |
| 可叠加组合 C-1 (pow23+wmse_th) | 08.15 | 跨层组合 | 待判定标准批注后，按"新基线+单变量"框架 | ⬜ |
| 可叠加组合 C-2 (block+wmse_th) | 08.15 | 跨层组合 | 同上 | ⬜ |
| 极小值专项评估 | 08.15 | 阶段3前置 | ✅ EXP-24 已完成（08-20）：谷值区系统性弱，阶段3 谷值需专门策略 | ✅ 完成 |
| 误差分解（偏差/方差） | 08.14 | 阶段1价值D项 | ❌ 暂不做：单种子无法标准分解，替代版判据已被探索期实验直接回答；留作组合实验异常时的诊断手段 | ⬜ 诊断备用 |
| 变换/loss 优胜者 W2/W3 验证 | 08.15 | 泛化验证 | 待判定批注后 | ⬜ |
| **Q9 平滑数据口径** | 10.11 更新 | 景修定 | **训练口径暂不动**（换口径＝同时换尺子，历史全废）。**基线定后开一个新实验分支，用平滑序列重训，超参沿用非平滑基线**。交付口径形式（"一个数+区间+换算说明"）**景修持怀疑态度，放基线之后研究**。附数据版本核对（398.2 疑点） | 🔜 基线后 |
| **交付口径（25 周谷值）** | 10.11 | 谷值讨论 | 候选=最小年给区间 + 谷窗口均值 + 不确定性说明；"三件套"并列形式可行性存疑（预测序列做平滑信息量低、易被读成两个独立估计）。**先不深入，放基线之后** | ⬜ 待研究 |
| **文档架构 STATE.md（L1）** | 10.11 | 文档治理讨论 | 景修选定 L1（字段化状态表 + 证据指针 + 脚本生成一半）。**前提=维护办法先讨论清楚并确保执行到位**，未定不建 | 🔜 维护办法待定 |
| **谷区加权 loss（低值加权）** | 10.11 | 谷值讨论（P6 备选） | **已评估，暂不尝试**（景修 10-11 决定）：①加权只改目标分布、不给新信息（谷区报错源于"这次极小期会特别长"在历史里几乎无先例：SSN≤3 连续段 76 段、中位 1 月、仅 2 段≥13 月）；②零和已有前例（wmse 峰改善 92% 但全步恶化 14.6%）；③**最大风险=加剧峰值压制**（峰值已被压 216→113）。替代候选=分位数回归 / 谷区上界约束（记录在 `plan_preregistration_2026-10-11.md`） | ✅ 已记录 |
| **轨迹"稳/失控双分支"机理** | 10.11 | EXP-23-R3 | 块长扫描推翻"回填频率是主因"：block=2/3 有时优于 24 → 不是单调，而是"稳/失控"双分支；可用判据=minimax（block24 最坏值最小）→ 维持 block24 | ✅ 已回填 |
| **多配置集成** | 10.11 | EXP-23-R3 引发 | 不同 dropout / 不同目标变换的模型各跑一条 block24 轨迹取中位数（失效模式不相关，可部署）。**冻结至基线找到后** | ⬜ 入队 |
| 单种子解决·多种子重跑 | 08.20 | 图规范讨论 | 历史关键配置仍未补；B26M P36/P24 已完成 2019–2021，B26M lr 已完成 P36 三 seed | 🟡 原方案 seed2022/2023 未做 |
| 单种子解决·bootstrap CI | 08.20 | 图规范讨论 | 对现有预测窗口做 bootstrap 重采样，得评估方差 95% CI。想法级，成本~30分钟 | ⬜ 画图时配套 |
| **峰值指标升为并列主指标**（判定标准③的替代方案） | 10.10 | 判定标准讨论 | 待景修批注；完整思路见下方「专项说明 A」 | ⬜ 批注后定稿 |
| **滚动数字必须记录段长** | 10.10 | 换机后复盘（坑 32） | `roll_eval.py` 默认值已修；**10-10 起的记录已逐条带段长**；历史记录里的旧滚动数（50.41/66.80/42.05/149.92/54.77）**尚未逐条补标**，混用风险仍在 | 🔜 补标 |
| **dropout 在滚动口径下方向反转的核实** | 10.11 收口 | 换机后复盘 | ✅ **已完成（EXP-26 + EXP-27~30 + EXP-23-R2/R3）**：do0.05 的滚动是**高方差**（41.63/109.62/23.28，波动 4.7x）而非更好；do0.2 稳定（50.29/47.95/43.65，1.15x）。→ **滚动不作为选型依据、不用于跨环境比较**；do0.2 站得住 | ✅ 已完成 |

### 专项说明 A：峰值指标升为并列主指标（AI 提案，2026-10-10，待景修批注）

**背景**：判定标准③ 原条款是"全步 MAE 为主；峰值改善 ≥20% 且全步恶化 <5% 才判定'峰值有效'"。
EXP-20-3（wmse）实测峰值改善 92%（滚动峰 −26.7 → −2.2），但全步恶化 14.6% → 按原条款判"峰值无效"。
AI 当时的建议是把全步容忍度从 5% 放宽到 15%。

**为什么不采用"放宽阈值"**：15% 是拍出来的数字，没有结构；门槛一松，任何"全步轻微恶化"都可能
被峰值单项的亮眼改善掩盖，等于用更松的门槛换更松的判定，容易把凑数的东西放进结论。

**提案**：不动阈值，改为**把峰值指标提升为并列主指标**——

| 指标 | 负责回答 | 判定角色 |
|------|---------|---------|
| 全步 MAE | 这个改动有没有把普遍精度搞坏？ | 守门：整体不退化 |
| E_r / 滚动峰误差 | 阶段3 真正要的峰值有没有变好？ | 目标：峰值精度 |

两个指标**同时报告、各自判定，不互相掩盖**。出现"一好一坏"时如实记为**权衡型结果**，
由用途决定取舍：阶段3 是外推场景，以峰值/滚动口径为主；全步保留为"整体体检"，防远期输出退化。

**为什么这条重要**：阶段3 的核心产出就是"26 周期最大值与最大时间"，峰值是**目标**不是副产品。
判定规则若只认全步，会把目前最有价值的那类改进判成无效，进而否掉组合实验 C-1/C-2 的动机。

**边界条件（防滥用）**：全步恶化 ≥15%、或滚动崩溃（量级级误差 / 负值崩塌）→ **一律判无效**，
不论峰值改善多少。这条守住 EXP-20-1（revin=0 滚动崩溃 1967 万）、EXP-20-2b（pl48 滚动 37 万）
这类崩溃结果不被误采信。

**待办**：景修批注后写入 `judgment_criteria_discussion_2026-08-15.md`，并据此回填 EXP-20~23 结论。

> **探索期队列豁免（2026-08-14，仅此一次，不修改 SOP §8）**：EXP-20-1~23-2（机制诊断 4 + 变换 3 + loss 4 + block 策略 2）是预先批准的整体探索队列，
> 一次性豁免"连续 3 个实验改善 <10% 停止"规则。仅此队列，之后的计划外追加实验仍受 §8 约束（组合实验 C-1/C-2 是新队列，启动前需景修重新预先批准）。
> 判定标准（固定锚/双指标条款/pred_len滚动判定）为待议项，讨论定稿前 EXP-20 系列不下有效/无效结论，仅收集数据。

---

### Git 推送 408 / 空连接（坑 37，2026-11-20 新增）

**现象**：`git push` 反复返回 HTTP 408，缩小到单个文件仍出现
`curl 52 Empty reply from server`。继续拆分 commit 并不能解决。

**根因**：Git 全局配置将 `https://github.com` 强制走内部代理，
而该代理下 Git smart-HTTP 的 `receive-pack` 通道不可用；
绕过代理直连 `api.github.com` 正常。

**排查顺序**：

1. `git ls-remote` 测读取通道；
2. `curl --noproxy '*' https://api.github.com` 测 API 直连；
3. 对比代理开启/关闭时 `github.com` 与 `api.github.com` 的连通性；
4. 只有确认是纯大小问题时才拆文件，不得先盲目反复拆包。

**回退方案**：若 API 直连可用，使用 GitHub Git Data REST API
上传一个压缩证据包并更新辅助分支 ref；凭据只从
`git credential fill` 进程中读取，不打印、不落盘。
不得 `--force` push，不得删除远端分支。

## 环境信息

| 项目 | 值 |
|------|-----|
| Python | 3.10.12 |
| PyTorch | 1.11.0 |
| GPU | 无（纯 CPU 训练） |
| 训练耗时 | seq=132/bs=32/50ep：约 22s/epoch（CPU），50 ep≈18 分钟。seq=96/bs=16/10ep：约 2-3 分钟 |
| 评估耗时 | npy 反算 + 4 指标：< 5 秒。滚动评估（70 次推理）：约 2-3 分钟 |
| Git token | 有效期至 **2026-10-10**。push 失败先检查 token 是否过期 |

---

## AI 执行规范

给 AI 看的固定信息，不推导。

### 路径（硬编码）

| 用途 | 路径 |
|------|------|
| 数据 | `PatchTST_supervised/dataset/sunspot_with_cycle.csv` |
| 训练入口 | `run_longExp.py`（原管线，`PYTHONPATH=PatchTST_supervised`） |
| 配置快照 | `../save_config.py` |
| 配置输出 | `../configs/` |
| 评估脚本 | `../scripts/eval_metrics.py` |
| 索引表 | `project_docs/experiment_history.md` 顶部 |
| 结果记录 | `../result.txt` |
| 单次记录模板 | `project_docs/experiment_template.md` |

### 四指标定义

- **step0 MAE**：`mean(abs(pred_phy[0] - true_phy[0]))` — 窗口 0 的全部 pred_len 步平均
- **全步 MAE**：`mean(abs(pred_phy - true_phy))` — 所有 47 窗口 × 24 步平均
- **E_r**：`max(pred_phy) - max(true_phy)` — 峰值幅度误差（正=高估，负=低估）
- **E_m**：预测峰值所在月份 - 真实峰值所在月份（正=偏晚，负=偏早）

### 索引表追加格式

```
| EXP-XX | YYYY-MM-DD | Stage | 改动 | 配置 | 全步MAE | step0 | R² | E_r | E_m | 结论 | 行号 | 有config? |
```

### 目录命名解析

- `sl`=seq_len / `pl`=pred_len / `ll`=label_len
- `dm`=d_model / `nh`=n_heads / `el`=e_layers / `df`=d_ff
- ⚠️ **`pl` 是 pred_len，不是 patch_len！** patch_len 和 stride 不在目录名中——只能在 config JSON 或 checkpoint 里确认。AI 写文档时曾将 `pl24` 误读为 `patch=24`，这是错的。

---

## 参考

| 文档 | 用途 |
|------|------|
| `project_docs/experiment_template.md` | 单次实验记录模板 |
| `project_docs/experiment_history.md` | 全量实验索引 + 详情 |
| `project_docs/data_pipeline.md` | 归一化方法、数据流、硬编码约束 |
| `project_docs/ONBOARDING.md` | 给新来 AI 的说明——她是谁、怎么沟通、今天踩了什么坑 |
| `AGENTS.md` | 项目架构、基线参数、红线 |
| `project_docs/project_roadmap.md` | 路线图、下一步任务 |
