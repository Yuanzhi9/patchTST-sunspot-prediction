#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

export PYTHONPATH="$ROOT/PatchTST_supervised:/openbayes/home/python-packages"
export OMP_NUM_THREADS=4

echo "[$(date '+%F %T')] PR132 standard search: search"
python3 -u scripts/run_pr132_standard_search.py search

echo "[$(date '+%F %T')] PR132 standard search: refine"
python3 -u scripts/run_pr132_standard_search.py refine

echo "[$(date '+%F %T')] PR132 standard search: audit"
python3 -u scripts/run_pr132_standard_search.py audit

echo "[$(date '+%F %T')] PR132 standard search: finalize"
python3 -u scripts/run_pr132_standard_search.py finalize

echo "[$(date '+%F %T')] PR132 standard search: complete"
